这是 patched 文件夹下 SSDT 热补丁反编译后的源代码，方便部分用户预览代码和自行修改。

This directory contains the decompiled source code of AML binary files in `patched` directory. You can preview the dsl code or modify them by yourself.